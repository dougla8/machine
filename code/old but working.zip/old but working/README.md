## Email Previewer

View past campaigns using this tool. Add more campaigns using this spreadsheet - 
https://docs.google.com/spreadsheets/d/1OoXp3OBu8nOGvHdTD2D6wtuUH9Dc-Y9qs4vqi2JDIBc/edit#gid=0


### Using your own Doc

Replace line 91 with your spreadsheets unique ID, normally found after - https://docs.google.com/spreadsheets/d/

var spreadsheetID = "1OoXp3OBu8nOGvHdTD2D6wtuUH9Dc-Y9qs4vqi2JDIBc";


### To-do

1. Searchbox working
2. ~~Date filter message fade out delay~~
3. ~~Add tags to email~~
4. ~~show email by tag filter~~
5. side by side layouts
6. ~~yearly spreadsheets merged into one~~